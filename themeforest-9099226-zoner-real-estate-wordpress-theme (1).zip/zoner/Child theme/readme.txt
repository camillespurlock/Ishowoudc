
= Child theme installation =

If you want to add changes of your own to the theme core files, we recommend to use a child theme.
To install the child theme, follow these steps.

1. Install ZONER theme. 
2. Go to Appearance > Themes > Upload the zoner-child zip folder and activate child theme.

For more complex changes documentation, go to http://codex.wordpress.org/Child_Themes